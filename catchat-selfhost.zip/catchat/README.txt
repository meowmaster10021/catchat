CATCHAT - run it yourself (no accounts, no cloud)
The site loads nothing from any other website: no fonts, no libraries, no
external services. Everything it needs is in this folder.

1. Install Node.js 22.13 or newer from nodejs.org (the LTS download is fine).
2. Unzip this folder anywhere.
3. Start it:
   - Windows: double-click start.bat
   - Mac/Linux: open a terminal in this folder and run ./start.sh
   It asks for the meowmaster100 admin password. Use the SAME password every
   time you start it (the password you type is always the admin password).
4. Open http://localhost:8080 and log in as meowmaster100.

Everything (accounts, coins, items, chat) is saved in the "data" folder next
to server.js. Back that folder up to keep your data. Delete it to start fresh.

SHARING WITH OTHER PEOPLE
- Same Wi-Fi: they open http://YOUR-COMPUTER-IP:8080 (you may need to allow
  Node through your firewall).
- Over the internet, easiest: a temporary public link with Cloudflare's
  "cloudflared tunnel --url http://localhost:8080" (no account needed).
  The link changes each time you run it, and only works while your computer
  and the server are on.
- Always-on: copy this folder to any small Linux server (VPS), install
  Node 22.13+, and run ./start.sh (use a tool like pm2 or systemd to keep it
  running). Put it behind HTTPS (e.g. Caddy) before real use.
