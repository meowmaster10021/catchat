#!/bin/sh
cd "$(dirname "$0")"
if [ -z "$ADMIN_PASSWORD" ]; then printf "Choose the meowmaster100 admin password (6+ characters): "; read ADMIN_PASSWORD; fi
export ADMIN_PASSWORD DATA_DIR="$(pwd)/data" PORT="${PORT:-8080}"
echo "Starting CatChat at http://localhost:$PORT  (Ctrl+C to stop)"
node --no-warnings server.js
