@echo off
cd /d "%~dp0"
if "%ADMIN_PASSWORD%"=="" set /p ADMIN_PASSWORD=Choose the meowmaster100 admin password (6+ characters): 
set DATA_DIR=%~dp0data
if "%PORT%"=="" set PORT=8080
echo Starting CatChat at http://localhost:%PORT%  (close this window to stop)
node --no-warnings server.js
pause
